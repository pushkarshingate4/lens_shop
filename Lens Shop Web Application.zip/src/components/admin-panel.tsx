import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ArrowLeft, Plus, Package, Settings, Users, BarChart3 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from "sonner@2.0.3";
import { projectId } from '../utils/supabase/info';
import type { User as UserType, Product } from '../App';

interface AdminPanelProps {
  user: UserType;
  accessToken: string;
  onBack: () => void;
}

export function AdminPanel({ user, accessToken, onBack }: AdminPanelProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddProduct, setShowAddProduct] = useState(false);
  
  // New product form state
  const [newProduct, setNewProduct] = useState({
    name: '',
    type: 'contact-lenses' as 'contact-lenses' | 'eyeglasses',
    brand: '',
    price: '',
    description: '',
    image: '',
    prescriptionRequired: true,
    category: '',
    material: '',
    waterContent: '',
    uvProtection: false,
    frameColor: '',
    lensColor: '',
    inStock: true
  });

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/products`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setProducts(data.products || []);
      }
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProduct.name || !newProduct.brand || !newProduct.price || !newProduct.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const productData = {
        ...newProduct,
        price: parseFloat(newProduct.price),
        waterContent: newProduct.waterContent || undefined,
        material: newProduct.material || undefined,
        frameColor: newProduct.frameColor || undefined,
        lensColor: newProduct.lensColor || undefined,
      };

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/products`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      });

      if (response.ok) {
        toast.success('Product added successfully!');
        setNewProduct({
          name: '',
          type: 'contact-lenses',
          brand: '',
          price: '',
          description: '',
          image: '',
          prescriptionRequired: true,
          category: '',
          material: '',
          waterContent: '',
          uvProtection: false,
          frameColor: '',
          lensColor: '',
          inStock: true
        });
        setShowAddProduct(false);
        loadProducts();
      } else {
        const errorData = await response.json();
        toast.error(`Failed to add product: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Error adding product:', error);
      toast.error('Failed to add product');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Shop
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
        </div>
        <Badge className="bg-purple-600">Administrator</Badge>
      </div>

      <Tabs defaultValue="products" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-6">
          {/* Products Management */}
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900">Product Management</h2>
            <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddProduct} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Product Name *</Label>
                      <Input
                        id="name"
                        value={newProduct.name}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="type">Type *</Label>
                      <Select value={newProduct.type} onValueChange={(value: any) => setNewProduct(prev => ({ ...prev, type: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="contact-lenses">Contact Lenses</SelectItem>
                          <SelectItem value="eyeglasses">Eyeglasses</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="brand">Brand *</Label>
                      <Input
                        id="brand"
                        value={newProduct.brand}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, brand: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="price">Price *</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input
                        id="category"
                        value={newProduct.category}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, category: e.target.value }))}
                        placeholder="daily, monthly, sunglasses, etc."
                      />
                    </div>
                    <div>
                      <Label htmlFor="image">Image URL</Label>
                      <Input
                        id="image"
                        value={newProduct.image}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, image: e.target.value }))}
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      value={newProduct.description}
                      onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                      rows={3}
                      required
                    />
                  </div>

                  {/* Contact Lens Specific Fields */}
                  {newProduct.type === 'contact-lenses' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="material">Material</Label>
                        <Input
                          id="material"
                          value={newProduct.material}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, material: e.target.value }))}
                          placeholder="Silicone Hydrogel"
                        />
                      </div>
                      <div>
                        <Label htmlFor="waterContent">Water Content</Label>
                        <Input
                          id="waterContent"
                          value={newProduct.waterContent}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, waterContent: e.target.value }))}
                          placeholder="48%"
                        />
                      </div>
                    </div>
                  )}

                  {/* Eyeglasses Specific Fields */}
                  {newProduct.type === 'eyeglasses' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="frameColor">Frame Color</Label>
                        <Input
                          id="frameColor"
                          value={newProduct.frameColor}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, frameColor: e.target.value }))}
                          placeholder="Black, Gold, etc."
                        />
                      </div>
                      <div>
                        <Label htmlFor="lensColor">Lens Color</Label>
                        <Input
                          id="lensColor"
                          value={newProduct.lensColor}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, lensColor: e.target.value }))}
                          placeholder="Clear, Green, etc."
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="prescriptionRequired"
                        checked={newProduct.prescriptionRequired}
                        onCheckedChange={(checked) => setNewProduct(prev => ({ ...prev, prescriptionRequired: checked }))}
                      />
                      <Label htmlFor="prescriptionRequired">Prescription Required</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="uvProtection"
                        checked={newProduct.uvProtection}
                        onCheckedChange={(checked) => setNewProduct(prev => ({ ...prev, uvProtection: checked }))}
                      />
                      <Label htmlFor="uvProtection">UV Protection</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="inStock"
                        checked={newProduct.inStock}
                        onCheckedChange={(checked) => setNewProduct(prev => ({ ...prev, inStock: checked }))}
                      />
                      <Label htmlFor="inStock">In Stock</Label>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button type="submit" className="flex-1">Add Product</Button>
                    <Button type="button" variant="outline" onClick={() => setShowAddProduct(false)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Products List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full flex items-center justify-center h-32">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : products.length === 0 ? (
              <div className="col-span-full text-center py-8">
                <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-600">Add your first product to get started</p>
              </div>
            ) : (
              products.map((product) => (
                <Card key={product.id}>
                  <CardContent className="p-4">
                    <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-4">
                      <ImageWithFallback
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-semibold truncate">{product.name}</h3>
                      <p className="text-sm text-gray-600">{product.brand}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-blue-600">${product.price.toFixed(2)}</span>
                        <div className="flex space-x-1">
                          {product.prescriptionRequired && (
                            <Badge className="text-xs bg-blue-600">Rx</Badge>
                          )}
                          <Badge 
                            variant={product.inStock ? "default" : "destructive"}
                            className="text-xs"
                          >
                            {product.inStock ? 'In Stock' : 'Out of Stock'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="orders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Order Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Order management coming soon</h3>
                <p className="text-gray-600">View and manage customer orders here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">User management coming soon</h3>
                <p className="text-gray-600">View and manage customer accounts here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Products</p>
                    <p className="text-2xl font-bold text-gray-900">{products.length}</p>
                  </div>
                  <Package className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">In Stock</p>
                    <p className="text-2xl font-bold text-green-600">
                      {products.filter(p => p.inStock).length}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Contact Lenses</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {products.filter(p => p.type === 'contact-lenses').length}
                    </p>
                  </div>
                  <Settings className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Eyeglasses</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {products.filter(p => p.type === 'eyeglasses').length}
                    </p>
                  </div>
                  <Settings className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}