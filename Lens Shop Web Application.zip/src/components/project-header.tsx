import React from 'react';

interface ProjectHeaderProps {
  title: string;
}

export function ProjectHeader({ title }: ProjectHeaderProps) {
  return (
    <div className="bg-blue-600 text-white py-2 px-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-sm font-medium">{title} - Full-Stack E-commerce Platform</h1>
      </div>
    </div>
  );
}