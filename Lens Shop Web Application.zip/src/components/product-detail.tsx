import React, { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowLeft, ShoppingCart, Star, Eye, Shield, Truck } from 'lucide-react';
import type { Product } from '../App';

interface ProductDetailProps {
  product: Product;
  onAddToCart: (productId: string, quantity: number, prescriptionDetails?: any) => void;
  onBack: () => void;
}

export function ProductDetail({ product, onAddToCart, onBack }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [prescriptionDetails, setPrescriptionDetails] = useState({
    rightEye: { sphere: '', cylinder: '', axis: '', add: '' },
    leftEye: { sphere: '', cylinder: '', axis: '', add: '' },
    notes: ''
  });

  const handleAddToCart = () => {
    const details = product.prescriptionRequired ? prescriptionDetails : undefined;
    onAddToCart(product.id, quantity, details);
  };

  const isPrescriptionComplete = () => {
    if (!product.prescriptionRequired) return true;
    
    const { rightEye, leftEye } = prescriptionDetails;
    return rightEye.sphere && rightEye.cylinder && rightEye.axis &&
           leftEye.sphere && leftEye.cylinder && leftEye.axis;
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Products
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="space-y-4">
          <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center space-x-2 mb-2">
              <Badge variant="outline">{product.brand}</Badge>
              <Badge>{product.type === 'contact-lenses' ? 'Contact Lenses' : 'Eyeglasses'}</Badge>
              {product.prescriptionRequired && (
                <Badge className="bg-blue-600">Prescription Required</Badge>
              )}
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
            <div className="flex items-center space-x-2 mb-4">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${i < 4 ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                  />
                ))}
              </div>
              <span className="text-gray-600">(4.0) • 127 reviews</span>
            </div>
            <p className="text-2xl font-bold text-blue-600 mb-4">${product.price.toFixed(2)}</p>
            <p className="text-gray-700">{product.description}</p>
          </div>

          {/* Product Specifications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="h-5 w-5 mr-2" />
                Product Specifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {product.material && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Material:</span>
                  <span className="font-medium">{product.material}</span>
                </div>
              )}
              {product.waterContent && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Water Content:</span>
                  <span className="font-medium">{product.waterContent}</span>
                </div>
              )}
              {product.uvProtection !== undefined && (
                <div className="flex justify-between">
                  <span className="text-gray-600">UV Protection:</span>
                  <span className="font-medium">{product.uvProtection ? 'Yes' : 'No'}</span>
                </div>
              )}
              {product.frameColor && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Frame Color:</span>
                  <span className="font-medium">{product.frameColor}</span>
                </div>
              )}
              {product.lensColor && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Lens Color:</span>
                  <span className="font-medium">{product.lensColor}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Prescription Details */}
          {product.prescriptionRequired && (
            <Card>
              <CardHeader>
                <CardTitle>Prescription Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-6">
                  {/* Right Eye */}
                  <div className="space-y-3">
                    <h4 className="font-medium">Right Eye (OD)</h4>
                    <div className="space-y-2">
                      <div>
                        <Label htmlFor="right-sphere">Sphere (SPH)</Label>
                        <Input
                          id="right-sphere"
                          value={prescriptionDetails.rightEye.sphere}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            rightEye: { ...prev.rightEye, sphere: e.target.value }
                          }))}
                          placeholder="+2.00"
                        />
                      </div>
                      <div>
                        <Label htmlFor="right-cylinder">Cylinder (CYL)</Label>
                        <Input
                          id="right-cylinder"
                          value={prescriptionDetails.rightEye.cylinder}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            rightEye: { ...prev.rightEye, cylinder: e.target.value }
                          }))}
                          placeholder="-1.25"
                        />
                      </div>
                      <div>
                        <Label htmlFor="right-axis">Axis</Label>
                        <Input
                          id="right-axis"
                          value={prescriptionDetails.rightEye.axis}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            rightEye: { ...prev.rightEye, axis: e.target.value }
                          }))}
                          placeholder="180"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Left Eye */}
                  <div className="space-y-3">
                    <h4 className="font-medium">Left Eye (OS)</h4>
                    <div className="space-y-2">
                      <div>
                        <Label htmlFor="left-sphere">Sphere (SPH)</Label>
                        <Input
                          id="left-sphere"
                          value={prescriptionDetails.leftEye.sphere}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            leftEye: { ...prev.leftEye, sphere: e.target.value }
                          }))}
                          placeholder="+2.00"
                        />
                      </div>
                      <div>
                        <Label htmlFor="left-cylinder">Cylinder (CYL)</Label>
                        <Input
                          id="left-cylinder"
                          value={prescriptionDetails.leftEye.cylinder}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            leftEye: { ...prev.leftEye, cylinder: e.target.value }
                          }))}
                          placeholder="-1.25"
                        />
                      </div>
                      <div>
                        <Label htmlFor="left-axis">Axis</Label>
                        <Input
                          id="left-axis"
                          value={prescriptionDetails.leftEye.axis}
                          onChange={(e) => setPrescriptionDetails(prev => ({
                            ...prev,
                            leftEye: { ...prev.leftEye, axis: e.target.value }
                          }))}
                          placeholder="180"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="prescription-notes">Additional Notes (Optional)</Label>
                  <Textarea
                    id="prescription-notes"
                    value={prescriptionDetails.notes}
                    onChange={(e) => setPrescriptionDetails(prev => ({
                      ...prev,
                      notes: e.target.value
                    }))}
                    placeholder="Any special instructions or notes about your prescription..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quantity and Add to Cart */}
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Label htmlFor="quantity">Quantity:</Label>
                  <Select value={quantity.toString()} onValueChange={(value) => setQuantity(parseInt(value))}>
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map(num => (
                        <SelectItem key={num} value={num.toString()}>{num}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  size="lg" 
                  className="w-full"
                  onClick={handleAddToCart}
                  disabled={!product.inStock || (product.prescriptionRequired && !isPrescriptionComplete())}
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  {product.inStock ? 'Add to Cart' : 'Out of Stock'}
                </Button>

                {product.prescriptionRequired && !isPrescriptionComplete() && (
                  <p className="text-sm text-amber-600 text-center">
                    Please complete prescription details to add to cart
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Guarantees */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Shield className="h-5 w-5 text-green-600" />
              <span>Quality Guaranteed</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Truck className="h-5 w-5 text-blue-600" />
              <span>Free Shipping</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Eye className="h-5 w-5 text-purple-600" />
              <span>30-Day Returns</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}