import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Minus, Plus, Trash2, ShoppingBag, CreditCard } from 'lucide-react';
import type { CartItem } from '../App';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export function Cart({ items, onUpdateQuantity, onProceedToCheckout, onContinueShopping }: CartProps) {
  const totalAmount = items.reduce((sum, item) => {
    return sum + (item.product?.price || 0) * item.quantity;
  }, 0);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  if (items.length === 0) {
    return (
      <div className="text-center py-12">
        <ShoppingBag className="h-24 w-24 text-gray-300 mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
        <p className="text-gray-600 mb-8">Add some items to your cart to get started</p>
        <Button onClick={onContinueShopping} size="lg">
          Continue Shopping
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Shopping Cart</h1>
        <Badge variant="outline" className="text-lg px-3 py-1">
          {totalItems} {totalItems === 1 ? 'item' : 'items'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <Card key={item.productId}>
              <CardContent className="p-6">
                <div className="flex space-x-4">
                  {/* Product Image */}
                  <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <ImageWithFallback
                      src={item.product?.image || ''}
                      alt={item.product?.name || ''}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Product Details */}
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-gray-900">{item.product?.name}</h3>
                        <p className="text-sm text-gray-600">{item.product?.brand}</p>
                        {item.product?.prescriptionRequired && (
                          <Badge className="mt-1 bg-blue-600">Prescription Required</Badge>
                        )}
                      </div>
                      <p className="font-bold text-blue-600">
                        ${((item.product?.price || 0) * item.quantity).toFixed(2)}
                      </p>
                    </div>

                    {/* Prescription Details */}
                    {item.prescriptionDetails && (
                      <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                        <p className="font-medium mb-2">Prescription Details:</p>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="font-medium">Right Eye:</p>
                            <p>SPH: {item.prescriptionDetails.rightEye.sphere}</p>
                            <p>CYL: {item.prescriptionDetails.rightEye.cylinder}</p>
                            <p>AXIS: {item.prescriptionDetails.rightEye.axis}</p>
                          </div>
                          <div>
                            <p className="font-medium">Left Eye:</p>
                            <p>SPH: {item.prescriptionDetails.leftEye.sphere}</p>
                            <p>CYL: {item.prescriptionDetails.leftEye.cylinder}</p>
                            <p>AXIS: {item.prescriptionDetails.leftEye.axis}</p>
                          </div>
                        </div>
                        {item.prescriptionDetails.notes && (
                          <p className="mt-2">
                            <span className="font-medium">Notes:</span> {item.prescriptionDetails.notes}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Quantity Controls */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onUpdateQuantity(item.productId, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="font-medium w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onUpdateQuantity(item.productId, item.quantity + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onUpdateQuantity(item.productId, 0)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal ({totalItems} items)</span>
                  <span className="font-medium">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium text-green-600">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax</span>
                  <span className="font-medium">${(totalAmount * 0.08).toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span className="text-blue-600">${(totalAmount * 1.08).toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-3">
                <Button className="w-full" size="lg" onClick={onProceedToCheckout}>
                  <CreditCard className="h-5 w-5 mr-2" />
                  Proceed to Checkout
                </Button>
                <Button variant="outline" className="w-full" onClick={onContinueShopping}>
                  Continue Shopping
                </Button>
              </div>

              {/* Benefits */}
              <div className="text-sm text-gray-600 space-y-2 pt-4 border-t">
                <p className="flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Free shipping on all orders
                </p>
                <p className="flex items-center">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  30-day return policy
                </p>
                <p className="flex items-center">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Secure checkout
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}