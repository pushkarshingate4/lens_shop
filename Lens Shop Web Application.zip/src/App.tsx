import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { toast } from "sonner@2.0.3";
import { Toaster } from './components/ui/sonner';
import { ShoppingCart, User, Search, Menu, Eye, Users, Package } from 'lucide-react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Badge } from './components/ui/badge';
import { ProjectHeader } from './components/project-header';
import { ProductCatalog } from './components/product-catalog';
import { ProductDetail } from './components/product-detail';
import { Cart } from './components/cart';
import { Checkout } from './components/checkout';
import { AuthModal } from './components/auth-modal';
import { UserProfile } from './components/user-profile';
import { AdminPanel } from './components/admin-panel';
import { projectId, publicAnonKey } from './utils/supabase/info';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

export type Product = {
  id: string;
  name: string;
  type: 'contact-lenses' | 'eyeglasses';
  brand: string;
  price: number;
  description: string;
  image: string;
  prescriptionRequired: boolean;
  category: string;
  inStock: boolean;
  [key: string]: any;
};

export type CartItem = {
  productId: string;
  quantity: number;
  prescriptionDetails?: any;
  product?: Product;
};

export type User = {
  id: string;
  email: string;
  user_metadata: {
    name: string;
  };
};

type Page = 'catalog' | 'product' | 'cart' | 'checkout' | 'profile' | 'admin';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('catalog');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Initialize app
  useEffect(() => {
    initializeApp();
    checkAuthSession();
  }, []);

  const initializeApp = async () => {
    try {
      // Initialize sample products
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/init-products`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        console.log('App initialized successfully');
      }
    } catch (error) {
      console.error('Failed to initialize app:', error);
    }
  };

  const checkAuthSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (session && session.access_token) {
        setUser(session.user as User);
        setAccessToken(session.access_token);
        loadCart(session.access_token);
      }
    } catch (error) {
      console.error('Error checking auth session:', error);
    }
  };

  const loadCart = async (token: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/cart`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCartItems(data.cart.items || []);
      }
    } catch (error) {
      console.error('Failed to load cart:', error);
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast.error(`Login failed: ${error.message}`);
        return false;
      }

      if (session) {
        setUser(session.user as User);
        setAccessToken(session.access_token);
        setShowAuthModal(false);
        loadCart(session.access_token);
        toast.success('Successfully logged in!');
        return true;
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please try again.');
    }
    return false;
  };

  const handleSignup = async (email: string, password: string, name: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/signup`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password, name }),
      });

      if (response.ok) {
        toast.success('Account created! Please log in.');
        return true;
      } else {
        const errorData = await response.json();
        toast.error(`Signup failed: ${errorData.error}`);
        return false;
      }
    } catch (error) {
      console.error('Signup error:', error);
      toast.error('Signup failed. Please try again.');
      return false;
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setAccessToken(null);
      setCartItems([]);
      setCurrentPage('catalog');
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Failed to logout');
    }
  };

  const addToCart = async (productId: string, quantity: number, prescriptionDetails?: any) => {
    if (!user || !accessToken) {
      setShowAuthModal(true);
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/cart/add`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId, quantity, prescriptionDetails }),
      });

      if (response.ok) {
        loadCart(accessToken);
        toast.success('Added to cart!');
      } else {
        const errorData = await response.json();
        toast.error(`Failed to add to cart: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Add to cart error:', error);
      toast.error('Failed to add to cart');
    }
  };

  const updateCartItem = async (productId: string, quantity: number) => {
    if (!accessToken) return;

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-2f0b4556/cart/update`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productId, quantity }),
      });

      if (response.ok) {
        loadCart(accessToken);
      } else {
        const errorData = await response.json();
        toast.error(`Failed to update cart: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Update cart error:', error);
      toast.error('Failed to update cart');
    }
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const renderPage = () => {
    switch (currentPage) {
      case 'catalog':
        return (
          <ProductCatalog
            searchQuery={searchQuery}
            selectedCategory={selectedCategory}
            onProductSelect={(product) => {
              setSelectedProduct(product);
              setCurrentPage('product');
            }}
            onCategoryChange={setSelectedCategory}
          />
        );
      case 'product':
        return selectedProduct ? (
          <ProductDetail
            product={selectedProduct}
            onAddToCart={addToCart}
            onBack={() => setCurrentPage('catalog')}
          />
        ) : null;
      case 'cart':
        return (
          <Cart
            items={cartItems}
            onUpdateQuantity={updateCartItem}
            onProceedToCheckout={() => setCurrentPage('checkout')}
            onContinueShopping={() => setCurrentPage('catalog')}
          />
        );
      case 'checkout':
        return (
          <Checkout
            items={cartItems}
            user={user}
            accessToken={accessToken}
            onOrderComplete={() => {
              setCartItems([]);
              setCurrentPage('profile');
              toast.success('Order placed successfully!');
            }}
            onBack={() => setCurrentPage('cart')}
          />
        );
      case 'profile':
        return user ? (
          <UserProfile
            user={user}
            accessToken={accessToken}
            onBack={() => setCurrentPage('catalog')}
          />
        ) : null;
      case 'admin':
        return user ? (
          <AdminPanel
            user={user}
            accessToken={accessToken}
            onBack={() => setCurrentPage('catalog')}
          />
        ) : null;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <ProjectHeader title="LensShop" />
      
      {/* Navigation Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div 
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => setCurrentPage('catalog')}
            >
              <Eye className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">LensShop</span>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-lg mx-8">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2"
                />
              </div>
            </div>

            {/* Navigation Actions */}
            <div className="flex items-center space-x-4">
              {/* Cart */}
              <Button
                variant="ghost"
                size="sm"
                className="relative"
                onClick={() => setCurrentPage('cart')}
              >
                <ShoppingCart className="h-5 w-5" />
                {cartItemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full flex items-center justify-center text-xs">
                    {cartItemCount}
                  </Badge>
                )}
              </Button>

              {/* User Menu */}
              {user ? (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setCurrentPage('profile')}
                  >
                    <User className="h-5 w-5" />
                    <span className="ml-2">{user.user_metadata.name}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setCurrentPage('admin')}
                  >
                    <Package className="h-5 w-5" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    Logout
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setShowAuthModal(true)}>
                  <User className="h-5 w-5 mr-2" />
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderPage()}
      </main>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onLogin={handleLogin}
          onSignup={handleSignup}
        />
      )}

      <Toaster />
    </div>
  );
}