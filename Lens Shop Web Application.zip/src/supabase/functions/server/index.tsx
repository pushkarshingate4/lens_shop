import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize Supabase clients
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Utility function to get user from token
async function getUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) return null;
  
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
  if (error) {
    console.log("Error getting user:", error);
    return null;
  }
  return user;
}

// Health check endpoint
app.get("/make-server-2f0b4556/health", (c) => {
  return c.json({ status: "ok" });
});

// User signup endpoint
app.post("/make-server-2f0b4556/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log("Signup error:", error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.log("Signup error:", error);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// Get all products
app.get("/make-server-2f0b4556/products", async (c) => {
  try {
    const type = c.req.query("type"); // "contact-lenses" or "eyeglasses"
    const brand = c.req.query("brand");
    
    let products = await kv.getByPrefix("product:");
    
    // Filter by type if specified
    if (type) {
      products = products.filter(p => p.type === type);
    }
    
    // Filter by brand if specified
    if (brand) {
      products = products.filter(p => p.brand.toLowerCase().includes(brand.toLowerCase()));
    }
    
    return c.json({ products });
  } catch (error) {
    console.log("Error fetching products:", error);
    return c.json({ error: "Failed to fetch products" }, 500);
  }
});

// Get single product
app.get("/make-server-2f0b4556/products/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const product = await kv.get(`product:${id}`);
    
    if (!product) {
      return c.json({ error: "Product not found" }, 404);
    }
    
    return c.json({ product });
  } catch (error) {
    console.log("Error fetching product:", error);
    return c.json({ error: "Failed to fetch product" }, 500);
  }
});

// Create product (admin only)
app.post("/make-server-2f0b4556/products", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const product = await c.req.json();
    const id = crypto.randomUUID();
    
    const newProduct = {
      id,
      ...product,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`product:${id}`, newProduct);
    
    return c.json({ product: newProduct });
  } catch (error) {
    console.log("Error creating product:", error);
    return c.json({ error: "Failed to create product" }, 500);
  }
});

// Get user's cart
app.get("/make-server-2f0b4556/cart", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const cart = await kv.get(`cart:${user.id}`) || { items: [] };
    
    // Get full product details for cart items
    const cartWithProducts = await Promise.all(
      cart.items.map(async (item: any) => {
        const product = await kv.get(`product:${item.productId}`);
        return {
          ...item,
          product
        };
      })
    );
    
    return c.json({ cart: { ...cart, items: cartWithProducts } });
  } catch (error) {
    console.log("Error fetching cart:", error);
    return c.json({ error: "Failed to fetch cart" }, 500);
  }
});

// Add item to cart
app.post("/make-server-2f0b4556/cart/add", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { productId, quantity = 1, prescriptionDetails } = await c.req.json();
    
    const cart = await kv.get(`cart:${user.id}`) || { items: [] };
    
    // Check if item already exists in cart
    const existingItemIndex = cart.items.findIndex((item: any) => item.productId === productId);
    
    if (existingItemIndex >= 0) {
      cart.items[existingItemIndex].quantity += quantity;
    } else {
      cart.items.push({
        productId,
        quantity,
        prescriptionDetails,
        addedAt: new Date().toISOString()
      });
    }
    
    await kv.set(`cart:${user.id}`, cart);
    
    return c.json({ cart });
  } catch (error) {
    console.log("Error adding to cart:", error);
    return c.json({ error: "Failed to add to cart" }, 500);
  }
});

// Update cart item
app.put("/make-server-2f0b4556/cart/update", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { productId, quantity } = await c.req.json();
    
    const cart = await kv.get(`cart:${user.id}`) || { items: [] };
    
    if (quantity <= 0) {
      // Remove item if quantity is 0 or negative
      cart.items = cart.items.filter((item: any) => item.productId !== productId);
    } else {
      // Update quantity
      const itemIndex = cart.items.findIndex((item: any) => item.productId === productId);
      if (itemIndex >= 0) {
        cart.items[itemIndex].quantity = quantity;
      }
    }
    
    await kv.set(`cart:${user.id}`, cart);
    
    return c.json({ cart });
  } catch (error) {
    console.log("Error updating cart:", error);
    return c.json({ error: "Failed to update cart" }, 500);
  }
});

// Clear cart
app.delete("/make-server-2f0b4556/cart", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    await kv.set(`cart:${user.id}`, { items: [] });
    
    return c.json({ cart: { items: [] } });
  } catch (error) {
    console.log("Error clearing cart:", error);
    return c.json({ error: "Failed to clear cart" }, 500);
  }
});

// Create order
app.post("/make-server-2f0b4556/orders", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { shippingAddress, paymentMethod } = await c.req.json();
    
    // Get user's cart
    const cart = await kv.get(`cart:${user.id}`) || { items: [] };
    
    if (cart.items.length === 0) {
      return c.json({ error: "Cart is empty" }, 400);
    }
    
    // Calculate total
    let total = 0;
    const orderItems = await Promise.all(
      cart.items.map(async (item: any) => {
        const product = await kv.get(`product:${item.productId}`);
        if (product) {
          total += product.price * item.quantity;
          return {
            productId: item.productId,
            productName: product.name,
            price: product.price,
            quantity: item.quantity,
            prescriptionDetails: item.prescriptionDetails
          };
        }
        return null;
      })
    );
    
    const orderId = crypto.randomUUID();
    const order = {
      id: orderId,
      userId: user.id,
      userEmail: user.email,
      items: orderItems.filter(item => item !== null),
      total,
      shippingAddress,
      paymentMethod,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`order:${orderId}`, order);
    
    // Clear cart after successful order
    await kv.set(`cart:${user.id}`, { items: [] });
    
    return c.json({ order });
  } catch (error) {
    console.log("Error creating order:", error);
    return c.json({ error: "Failed to create order" }, 500);
  }
});

// Get user's orders
app.get("/make-server-2f0b4556/orders", async (c) => {
  try {
    const user = await getUser(c.req);
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const allOrders = await kv.getByPrefix("order:");
    const userOrders = allOrders.filter(order => order.userId === user.id);
    
    // Sort by creation date (newest first)
    userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return c.json({ orders: userOrders });
  } catch (error) {
    console.log("Error fetching orders:", error);
    return c.json({ error: "Failed to fetch orders" }, 500);
  }
});

// Initialize sample products
app.post("/make-server-2f0b4556/init-products", async (c) => {
  try {
    const existingProducts = await kv.getByPrefix("product:");
    if (existingProducts.length > 0) {
      return c.json({ message: "Products already initialized" });
    }

    const sampleProducts = [
      {
        id: "1",
        name: "Acuvue Oasys Daily",
        type: "contact-lenses",
        brand: "Johnson & Johnson",
        price: 45.99,
        description: "Daily disposable contact lenses with HydraLuxe technology for all-day comfort.",
        image: "https://images.unsplash.com/photo-1562868768-0f3936114bae?w=500&h=500&fit=crop",
        prescriptionRequired: true,
        category: "daily",
        material: "Senofilcon A",
        waterContent: "38%",
        uvProtection: true,
        inStock: true
      },
      {
        id: "2", 
        name: "Biofinity Monthly",
        type: "contact-lenses",
        brand: "CooperVision",
        price: 32.99,
        description: "Monthly silicone hydrogel contact lenses for extended wear comfort.",
        image: "https://images.unsplash.com/photo-1562868768-0f3936114bae?w=500&h=500&fit=crop",
        prescriptionRequired: true,
        category: "monthly",
        material: "Comfilcon A",
        waterContent: "48%",
        uvProtection: false,
        inStock: true
      },
      {
        id: "3",
        name: "Ray-Ban Aviator Classic",
        type: "eyeglasses",
        brand: "Ray-Ban",
        price: 165.99,
        description: "Iconic aviator sunglasses with classic gold frame and green lenses.",
        image: "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?w=500&h=500&fit=crop",
        prescriptionRequired: false,
        category: "sunglasses",
        frameColor: "Gold",
        lensColor: "Green Classic G-15",
        material: "Metal",
        inStock: true
      },
      {
        id: "4",
        name: "Oakley Holbrook",
        type: "eyeglasses", 
        brand: "Oakley",
        price: 143.99,
        description: "Modern square frame sunglasses with Prizm lens technology.",
        image: "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=500&h=500&fit=crop",
        prescriptionRequired: false,
        category: "sunglasses",
        frameColor: "Matte Black",
        lensColor: "Prizm Black",
        material: "O Matter",
        inStock: true
      },
      {
        id: "5",
        name: "Warby Parker Clark",
        type: "eyeglasses",
        brand: "Warby Parker",
        price: 95.99,
        description: "Classic rectangular prescription glasses with acetate frame.",
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500&h=500&fit=crop",
        prescriptionRequired: true,
        category: "prescription",
        frameColor: "Tortoise",
        lensType: "Single Vision",
        material: "Acetate",
        inStock: true
      }
    ];

    for (const product of sampleProducts) {
      await kv.set(`product:${product.id}`, { ...product, createdAt: new Date().toISOString() });
    }

    return c.json({ message: "Sample products initialized", count: sampleProducts.length });
  } catch (error) {
    console.log("Error initializing products:", error);
    return c.json({ error: "Failed to initialize products" }, 500);
  }
});

Deno.serve(app.fetch);